A Pen created at CodePen.io. You can find this one at http://codepen.io/nstanard/pen/kkvXao.

 Autoplay the slider with dot feedback.